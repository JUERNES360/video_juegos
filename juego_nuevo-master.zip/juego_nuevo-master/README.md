# pygame-Scripts
juego de disparos espaciales 2D. El jugador navega una nave espacial a través de  mundos diferentes en niveles verticales de desplazamiento y enemigos desafiantes, tratando de destruirlos o evitarlos.
